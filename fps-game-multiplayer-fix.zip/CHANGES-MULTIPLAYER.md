# گزارش مرحله ۱: تعمیر Multiplayer

PROBLEM:
اتصال چندنفره کار نمی‌کرد: دکمه‌های «ساخت اتاق»، «تولید کد پاسخ» و «تایید میزبان» عملاً کاری انجام نمی‌دادند یا کد خراب تولید می‌کردند.

ROOT CAUSE (به ترتیب شدت، همه از روی کد واقعی Repo):
1. world.js تابع `loadMap` را از maps.js ایمپورت می‌کرد ولی maps.js چنین Exportی نداشت.
   ⇒ خطای Link در ES Module ⇒ main.js اصلاً اجرا نمی‌شد (Solo هم خراب بود).
   منوها فقط به خاطر اسکریپت inline داخل index.html باز می‌شدند، برای همین به نظر می‌رسید فقط Multiplayer خراب است.
2. enemies.js دوبار Paste شده بود (نیمه دوم تکراری + `}` اضافه) ⇒ SyntaxError و Redeclaration.
3. index.html المان‌هایی که builder.js / main.js / controls.js لازم دارند را نداشت
   (btn-angle-plus، btn-place-block، minecraft-hotbar، gear-menu-modal، crate-prompt، hud-size-slider-bar، debug-console …).
   ⇒ `initBuilder()` با `null.addEventListener` کرش می‌کرد، قبل از اینکه Handlerهای دکمه‌های Multiplayer ثبت شوند.
4. `addSafeClick` هم pointerdown و هم click را گوش می‌داد ⇒ روی موبایل هر لمس دو بار اجرا می‌شد:
   دو Offer / دو Answer (اولی توسط resetNetwork بسته می‌شد و ممکن بود کد همان اتصال بسته‌شده نمایش داده شود) و دو بار setRemoteDescription (بار دوم خطای InvalidState ⇒ پیام «کد نامعتبر»).
5. مهمان بعد از انتخاب سلاح با نقشه پیش‌فرض خودش (maze) وارد بازی می‌شد نه نقشه میزبان؛ پیام init هم می‌توانست قبل از انتخاب نقشه با مقدار اشتباه ارسال شود.
6. Data Channel به صورت `ordered:false, maxRetransmits:0` بود ⇒ پیام‌های مهم (init / damage) ممکن بود گم شوند.
7. Fallback ۱.۵ ثانیه‌ای ممکن بود کد را قبل از جمع شدن ICE Candidateهای STUN تولید کند (مخصوصاً روی موبایل).

FILES CHANGED:
index.html, main.js, network.js, maps.js, world.js, enemies.js, builder.js
(بدون تغییر: engine.js, storage.js, player.js, weapons.js, controls.js, characters.js, style.css)

CHANGES:
- maps.js: اضافه شدن `loadMap(mapId, targetScene, isPreview)`؛ نقشه قبلی را حذف و currentMapId را ست می‌کند.
- world.js: پاکسازی نقشه قبلی قبل از ساخت جدید؛ Meshهای نقشه به solidObjects اضافه می‌شوند (بلوک‌های بیلدر و سنگر Stonewall حفظ می‌شوند).
- enemies.js: حذف نیمه تکراری (نسخه‌ای که 34-optimized.glb را لود می‌کند حفظ شد؛ enemy.glb در Repo وجود ندارد).
- index.html: بازگردانی المان‌های گمشده بر اساس Selectorهای موجود در style.css. هیچ ID قبلی تغییر نکرد.
- builder.js: دسترسی به DOM امن شد (optional chaining) تا نبودِ یک المان کل بازی را کرش ندهد.
- main.js:
  - addSafeClick با Debounce نیم‌ثانیه‌ای: هر لمس فقط یک بار اجرا می‌شود.
  - «تایید میزبان» فقط در صورت موفقیت به انتخاب کاراکتر می‌رود.
  - «ورود به مرحله بعد» فقط وقتی اتصال آماده است کار می‌کند.
  - مهمان نقشه را از میزبان می‌گیرد: اگر هنوز نرسیده، منتظر می‌ماند و خودکار وارد همان نقشه می‌شود.
  - شروع Solo اتصال نیمه‌کاره قبلی را ریست می‌کند.
  - HTML کارت‌های انتخاب با کلاس‌های card-icon / card-title / card-desc نوشته شد.
- network.js:
  - Guard برای جلوگیری از اجرای همزمان Offer/Answer.
  - صبر واقعی برای iceGatheringState = complete (Timeout پنج ثانیه).
  - Data Channel از نوع Reliable.
  - بررسی نوع کد (Offer/Answer) با پیام خطای واضح؛ فاصله/خط جدیدِ کپی‌شده حذف می‌شود.
  - کپی خودکار کد در Clipboard (اگر مرورگر اجازه دهد).
  - پیام‌های جدید `req` و `init`؛ announceHostMap / requestHostInit / setOnHostInit (callback، بدون Circular Import).
  - نمایش وضعیت اتصال در mp-chip و پیام در صورت failed شدن.

PRESERVED FEATURES:
همه قابلیت‌ها حفظ شدند: Solo، Build Mode، Hotbar، Weapons/Ammo/Reload/ADS/Recoil، Grenade، Hook، Jetpack، Wall Run، Slide، Enemy AI، Allies، Killstreak، Shield، Medkit، Care Package، Flare، Loot، Touch Controls، HUD Editing، Characters. پیام‌های شبکه m / s / h / g بدون تغییر.

TESTED:
- node --check روی همه فایل‌های تغییرکرده: بدون خطای Syntax.
- بررسی Import/Export بین همه ماژول‌ها: همه Importها وجود دارند.
- ترتیب ارزیابی ماژول‌ها برای خطای TDZ/Circular بررسی شد: مشکلی نیست.
- ⚠️ هنوز روی مرورگر/دو دستگاه واقعی تست نشده؛ لطفاً Solo Test و Multiplayer Test بخش ۴۰ را اجرا کن.

REMAINING ISSUES:
- TURN Server وجود ندارد: روی اینترنت موبایل (NAT متقارن اپراتورها) ممکن است با کد درست هم اتصال fail شود. تست اول را روی یک وای‌فای انجام بده.
- Damage بازیکن‌به‌بازیکن پیاده نشده: remotePlayer در Raycast شلیک نیست و پیام h هیچ‌وقت ارسال نمی‌شود.
- شلیک ممتد فقط یک پیام s می‌فرستد؛ نارنجک/Hook/Ability/Death/Respawn/Invisibility/Character/Weapon sync نمی‌شوند.
- Spawn میزبان در maze (0,1.8,0) داخل دیوار وسط است (از قبل همین بود).
- ترتیب فعلی Flow: اتصال ← کاراکتر ← سلاح ← نقشه (فقط میزبان). سند ترتیب «انتخاب‌ها ← ساخت اتاق» را خواسته؛ عمداً تغییر داده نشد تا Flow نشکند.
- engine.js یک previewRenderer بی‌استفاده می‌سازد (یک WebGL Context اضافه روی موبایل).
