import { scene } from './engine.js';
import { playSound, showToast } from './storage.js';
import { damagePlayer, player } from './player.js';
import { createTacticalCharacter } from './characters.js';
import { MAPS_DB } from './maps.js';

export let isMultiplayer = false;
export let isHost = false;
// نقشه‌ای که میزبان انتخاب کرده (در میزبان: نقشه اعلام‌شده، در مهمان: نقشه دریافتی)
export let hostMapId = null;

let peerConnection = null;
let dataChannel = null;
let signalingBusy = false;      // جلوگیری از اجرای همزمان Offer/Answer (دوبار اجرا شدن روی موبایل)
let hostAnswerApplied = false;  // آیا Answer مهمان روی میزبان اعمال شده است
let onHostInitCb = null;        // Callback برای main.js (جلوگیری از Circular Import)

// ساخت مدل سه‌بعدی تاکتیکی برای رقیب
export const remotePlayer = createTacticalCharacter(0xef4444);
remotePlayer.visible = false;
scene.add(remotePlayer);

export const remoteTarget = {
  pos: new THREE.Vector3(0, 0, 0),
  rotY: 0,
  isSliding: false
};

const rtcConfig = {
  iceServers: [
    { urls: 'stun:stun.l.google.com:19302' },
    { urls: 'stun:stun1.l.google.com:19302' },
    { urls: 'stun:stun2.l.google.com:19302' }
  ]
};

function logNet(msg, type = 'info') {
  const fullMsg = `[NETWORK] ${msg}`;
  if (type === 'err') console.error(fullMsg);
  else if (type === 'warn') console.warn(fullMsg);
  else console.log(fullMsg);
}

function safeEncode(obj) {
  return btoa(unescape(encodeURIComponent(JSON.stringify(obj))));
}

function safeDecode(str) {
  // حذف فاصله/خط جدیدی که ممکن است هنگام کپی در پیام‌رسان‌ها اضافه شود
  const clean = str.replace(/\s+/g, '');
  return JSON.parse(decodeURIComponent(escape(atob(clean))));
}

function setChip(text, color) {
  const chip = document.getElementById('mp-chip');
  if (chip) {
    chip.innerText = text;
    chip.style.color = color;
  }
}

function tryCopyToClipboard(text) {
  try {
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(text).catch(() => {});
    }
  } catch (e) {}
}

// صبر تا پایان جمع‌آوری ICE Candidateها (با Timeout) تا کد کامل ساخته شود
function waitForIceGathering(pc, timeoutMs = 5000) {
  return new Promise((resolve) => {
    if (pc.iceGatheringState === 'complete') return resolve();
    let done = false;
    const finish = () => {
      if (done) return;
      done = true;
      pc.removeEventListener('icegatheringstatechange', check);
      resolve();
    };
    const check = () => {
      if (pc.iceGatheringState === 'complete') finish();
    };
    pc.addEventListener('icegatheringstatechange', check);
    pc.addEventListener('icecandidate', (e) => { if (!e.candidate) finish(); });
    setTimeout(() => {
      if (!done) logNet(`ICE gathering timeout (state: ${pc.iceGatheringState}) - using gathered candidates`, 'warn');
      finish();
    }, timeoutMs);
  });
}

function attachStateLogs(pc, label) {
  pc.onconnectionstatechange = () => {
    if (pc !== peerConnection) return;
    logNet(`${label} Connection State: ${pc.connectionState}`);
    if (pc.connectionState === 'failed') {
      setChip('❌ اتصال ناموفق', '#ef4444');
      showToast('اتصال برقرار نشد (احتمالاً محدودیت شبکه/NAT)', '#ef4444');
    }
  };
  pc.oniceconnectionstatechange = () => {
    if (pc !== peerConnection) return;
    logNet(`${label} ICE Connection State: ${pc.iceConnectionState}`);
  };
}

export function setOnHostInit(cb) { onHostInitCb = cb; }

// آیا اجازه رفتن به مرحله انتخاب کاراکتر در حالت چندنفره وجود دارد
export function canProceedMultiplayer() {
  return isMultiplayer || (isHost && hostAnswerApplied);
}

// بستن و ریست اتصال قبلی در صورت وجود
export function resetNetwork() {
  if (dataChannel) {
    dataChannel.onopen = null;
    dataChannel.onclose = null;
    dataChannel.onerror = null;
    dataChannel.onmessage = null;
    try { dataChannel.close(); } catch (e) {}
    dataChannel = null;
  }
  if (peerConnection) {
    peerConnection.onicecandidate = null;
    peerConnection.ondatachannel = null;
    peerConnection.onconnectionstatechange = null;
    peerConnection.oniceconnectionstatechange = null;
    try { peerConnection.close(); } catch (e) {}
    peerConnection = null;
  }
  isMultiplayer = false;
  isHost = false;
  hostAnswerApplied = false;
  hostMapId = null;
  remotePlayer.visible = false;
  setChip('تک‌نفره', '#fff');
}

function sendHostInit() {
  if (!isHost || !hostMapId) return;
  sendNetworkData({
    t: 'init',
    map: hostMapId,
    hostSpawnIndex: 0,
    guestSpawnIndex: 1
  });
}

// میزبان: اعلام نقشه انتخابی (اگر کانال باز باشد فوراً ارسال می‌شود، وگرنه هنگام باز شدن)
export function announceHostMap(mapId) {
  hostMapId = mapId;
  sendHostInit();
}

// مهمان: درخواست اطلاعات نقشه از میزبان
export function requestHostInit() {
  sendNetworkData({ t: 'req' });
}

function setupDataChannelEvents(channel, onConnected) {
  dataChannel = channel;

  dataChannel.onopen = () => {
    isMultiplayer = true;
    remotePlayer.visible = true;
    logNet('Data Channel Open - Connection established successfully!');
    setChip(isHost ? '🟢 میزبان (متصل)' : '🟢 مهمان (متصل)', '#10b981');
    showToast('اتصال چندنفره برقرار شد!', '#10b981');

    // اگر میزبان قبلاً نقشه را انتخاب کرده، همین حالا برای مهمان بفرست
    if (isHost) sendHostInit();

    if (typeof onConnected === 'function') onConnected();
  };

  dataChannel.onclose = () => {
    logNet('Data Channel Closed', 'warn');
    isMultiplayer = false;
    remotePlayer.visible = false;
    setChip('قطع ارتباط', '#ef4444');
    showToast('ارتباط با رقیب قطع شد', '#ef4444');
  };

  dataChannel.onerror = (err) => {
    logNet(`DataChannel Error: ${(err && (err.message || (err.error && err.error.message))) || err}`, 'err');
  };

  dataChannel.onmessage = (e) => {
    try {
      const d = JSON.parse(e.data);

      // ۱. پیام راه‌اندازی اولیه توسط میزبان (فقط مهمان پردازش می‌کند)
      if (d.t === 'init') {
        if (isHost) return;
        if (!MAPS_DB[d.map]) {
          logNet(`Unknown map from host: ${d.map}`, 'err');
          return;
        }
        logNet(`Host selected map: ${d.map}`);
        hostMapId = d.map;
        if (typeof onHostInitCb === 'function') onHostInitCb(d);
      }

      // ۲. مهمان اطلاعات نقشه را درخواست کرده
      else if (d.t === 'req') {
        if (isHost) sendHostInit();
      }

      // ۳. داده‌های موقعیت و چرخش رقیب
      else if (d.t === 'm') {
        remoteTarget.pos.set(d.x, d.y - 1.8, d.z);
        remoteTarget.rotY = d.ry;
        remoteTarget.isSliding = !!d.sl;
      }

      // ۴. شلیک رقیب
      else if (d.t === 's') {
        playSound(600, 0.08, 'sawtooth', 0.25);
        const origin = remotePlayer.position.clone().add(new THREE.Vector3(0, 1.2, 0));
        const forward = new THREE.Vector3(0, 0, -1).applyAxisAngle(new THREE.Vector3(0, 1, 0), remoteTarget.rotY);
        const tr = new THREE.Mesh(
          new THREE.CylinderGeometry(0.03, 0.03, 20),
          new THREE.MeshBasicMaterial({ color: 0xfacc15 })
        );
        tr.position.copy(origin).add(forward.clone().multiplyScalar(10));
        tr.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), forward);
        scene.add(tr);
        setTimeout(() => scene.remove(tr), 50);
      }

      // ۵. دریافت دمیج از رقیب
      else if (d.t === 'h') {
        damagePlayer(d.dmg);
      }

      // ۶. پرتاب نارنجک رقیب
      else if (d.t === 'g') {
        playSound(350, 0.1, 'triangle', 0.3);
      }
    } catch (err) {
      logNet(`Parse incoming packet error: ${err}`, 'err');
    }
  };
}

// تولید Offer توسط میزبان
export async function createHostOffer() {
  if (signalingBusy) {
    logNet('createHostOffer ignored (already in progress)', 'warn');
    return;
  }
  signalingBusy = true;
  const hostBox = document.getElementById('host-offer-text');
  try {
    resetNetwork();
    isHost = true;
    logNet('Creating Host Offer...');
    if (hostBox) hostBox.value = 'در حال تجمیع کد شبکه (صبر کنید)...';

    const pc = new RTCPeerConnection(rtcConfig);
    peerConnection = pc;
    attachStateLogs(pc, 'Host');

    // کانال Reliable تا پیام‌های مهم (init / damage) گم نشوند
    const dc = pc.createDataChannel('game', { ordered: true });
    setupDataChannelEvents(dc, null);

    const offer = await pc.createOffer();
    await pc.setLocalDescription(offer);
    await waitForIceGathering(pc);

    if (pc !== peerConnection) return; // اتصال دیگری جایگزین شده

    const code = safeEncode(pc.localDescription);
    if (hostBox) {
      hostBox.value = code;
      hostBox.select();
    }
    tryCopyToClipboard(code);
    setChip('⏳ منتظر پاسخ مهمان', '#eab308');
    logNet('Host Offer ready.');
    showToast('کد اتاق ساخته شد! کپی کنید و به دوستتان بدهید', '#10b981');
  } catch (err) {
    logNet(`Create Offer Error: ${err.message || err}`, 'err');
    showToast('خطا در ساخت اتاق میزبان', '#ef4444');
    if (hostBox) hostBox.value = '';
  } finally {
    signalingBusy = false;
  }
}

// مهمان: تولید پاسخ با استفاده از کد میزبان
export async function createJoinAnswer(onConnected) {
  if (signalingBusy) {
    logNet('createJoinAnswer ignored (already in progress)', 'warn');
    return;
  }
  const joinInput = document.getElementById('join-offer-input');
  const joinAnswerBox = document.getElementById('join-answer-text');
  const val = joinInput ? joinInput.value.trim() : '';

  if (!val) {
    showToast('ابتدا کد میزبان را در کادر بالا وارد کنید', '#eab308');
    return;
  }

  let offerDesc;
  try {
    offerDesc = safeDecode(val);
  } catch (err) {
    logNet(`Offer decode error: ${err}`, 'err');
    showToast('کد میزبان نامعتبر است', '#ef4444');
    return;
  }
  if (!offerDesc || offerDesc.type !== 'offer') {
    showToast('این کد، کد اتاق میزبان (Offer) نیست', '#ef4444');
    return;
  }

  signalingBusy = true;
  try {
    resetNetwork();
    isHost = false;
    logNet('Creating Join Answer...');
    if (joinAnswerBox) joinAnswerBox.value = 'در حال تولید کد پاسخ (صبر کنید)...';

    const pc = new RTCPeerConnection(rtcConfig);
    peerConnection = pc;
    attachStateLogs(pc, 'Client');

    pc.ondatachannel = (e) => {
      if (pc !== peerConnection) return;
      logNet('Data Channel received by Client');
      setupDataChannelEvents(e.channel, onConnected);
    };

    await pc.setRemoteDescription(new RTCSessionDescription(offerDesc));
    logNet('Remote Offer Description set on Client');

    const answer = await pc.createAnswer();
    await pc.setLocalDescription(answer);
    await waitForIceGathering(pc);

    if (pc !== peerConnection) return;

    const code = safeEncode(pc.localDescription);
    if (joinAnswerBox) {
      joinAnswerBox.value = code;
      joinAnswerBox.select();
    }
    tryCopyToClipboard(code);
    setChip('⏳ منتظر تایید میزبان', '#eab308');
    showToast('کد پاسخ آماده شد! آن را برای میزبان بفرستید', '#10b981');
  } catch (err) {
    logNet(`Create Answer Error: ${err.message || err}`, 'err');
    showToast('کد میزبان نامعتبر است', '#ef4444');
    if (joinAnswerBox) joinAnswerBox.value = '';
  } finally {
    signalingBusy = false;
  }
}

// میزبان: تایید کد پاسخ ارسالی از مهمان. خروجی: true در صورت موفقیت
export async function connectHost() {
  if (!peerConnection || !isHost) {
    showToast('ابتدا «ساخت اتاق (میزبان)» را بزنید', '#eab308');
    return false;
  }
  // اگر Answer قبلاً اعمال شده (کلیک تکراری)، خطا نده
  if (hostAnswerApplied) return true;

  if (peerConnection.signalingState !== 'have-local-offer') {
    logNet(`connectHost: unexpected signaling state ${peerConnection.signalingState}`, 'warn');
    showToast('کد اتاق هنوز آماده نیست، چند لحظه صبر کنید', '#eab308');
    return false;
  }

  const hostAnswerInput = document.getElementById('host-answer-input');
  const val = hostAnswerInput ? hostAnswerInput.value.trim() : '';
  if (!val) {
    showToast('لطفاً کد پاسخ دوستتان را وارد کنید', '#eab308');
    return false;
  }

  try {
    const answerDesc = safeDecode(val);
    if (!answerDesc || answerDesc.type !== 'answer') {
      showToast('این کد، کد پاسخ مهمان (Answer) نیست', '#ef4444');
      return false;
    }
    await peerConnection.setRemoteDescription(new RTCSessionDescription(answerDesc));
    hostAnswerApplied = true;
    logNet('Remote Answer applied on Host!');
    setChip('⏳ در حال اتصال...', '#eab308');
    showToast('پاسخ مهمان تایید شد! در حال برقراری اتصال...', '#10b981');
    return true;
  } catch (err) {
    logNet(`Connect Host Error: ${err.message || err}`, 'err');
    showToast('کد پاسخ وارد شده نامعتبر است', '#ef4444');
    return false;
  }
}

export function sendNetworkData(data) {
  if (isMultiplayer && dataChannel && dataChannel.readyState === 'open') {
    try {
      dataChannel.send(JSON.stringify(data));
    } catch (e) {
      logNet(`Send Data Error: ${e}`, 'err');
    }
  }
}

export function updateNetwork(dt) {
  if (isMultiplayer && remotePlayer.visible) {
    // درونیابی موقعیت و چرخش برای جلوگیری از Jitter
    remotePlayer.position.lerp(remoteTarget.pos, Math.min(1.0, 16 * dt));

    let diffRot = remoteTarget.rotY - remotePlayer.rotation.y;
    while (diffRot < -Math.PI) diffRot += Math.PI * 2;
    while (diffRot > Math.PI) diffRot -= Math.PI * 2;
    remotePlayer.rotation.y += diffRot * Math.min(1.0, 14 * dt);

    if (remoteTarget.isSliding) {
      remotePlayer.rotation.z = THREE.MathUtils.lerp(remotePlayer.rotation.z, 0.35, 10 * dt);
    } else {
      remotePlayer.rotation.z = THREE.MathUtils.lerp(remotePlayer.rotation.z, 0, 10 * dt);
    }
  }
}
