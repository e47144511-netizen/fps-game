import { scene, camera, renderer, initEngine, previewScene } from './engine.js';
import { initWorld } from './world.js';
import { player, updatePlayer } from './player.js';
import { updateWeapons, addFireBullets, activateGoldenMag, setWeapon, WEAPONS_DB } from './weapons.js';
import { spawnEnemies, updateEnemies, spawnAlliedSoldiers, enemies, setAutoDropCallback } from './enemies.js';
import { initControls, moveInput, toggleHudEdit } from './controls.js';
import { toggleBuildMode, updateBuilder, initBuilder, isBuildMode } from './builder.js';
import { playSound, showToast } from './storage.js';
import {
  createHostOffer,
  connectHost,
  createJoinAnswer,
  sendNetworkData,
  updateNetwork,
  isMultiplayer,
  isHost,
  hostMapId,
  remotePlayer,
  resetNetwork,
  announceHostMap,
  requestHostInit,
  setOnHostInit,
  canProceedMultiplayer
} from './network.js';
import { CHARACTERS_DB, setCharacter, selectedCharacter, updateCharacters } from './characters.js';
import { MAPS_DB, startMapPreview, currentMapId } from './maps.js';

const dbgConsole = document.getElementById('debug-console');
const dbgContent = document.getElementById('debug-content');
document.getElementById('debug-header')?.addEventListener('click', () => {
  if (dbgConsole) {
    dbgConsole.classList.toggle('minimized');
    dbgConsole.classList.toggle('expanded');
  }
});

function safeStringify(obj) {
  try { return JSON.stringify(obj); } catch (e) { return String(obj); }
}

function logToDOM(msg, type) {
  if (!dbgContent) return;
  const el = document.createElement('div');
  el.style.marginBottom = '6px';
  el.style.borderBottom = '1px solid rgba(255,255,255,0.1)';
  el.style.paddingBottom = '4px';
  el.style.color = type === 'err' ? '#ef4444' : (type === 'warn' ? '#facc15' : '#38bdf8');
  el.textContent = `[${type.toUpperCase()}] ${msg}`;
  dbgContent.appendChild(el);
  dbgContent.scrollTop = dbgContent.scrollHeight;
}

const oLog = console.log, oWarn = console.warn, oErr = console.error;
console.log = (...a) => { oLog(...a); logToDOM(a.map(x => typeof x === 'object' ? safeStringify(x) : x).join(' '), 'log'); };
console.warn = (...a) => { oWarn(...a); logToDOM(a.map(x => typeof x === 'object' ? safeStringify(x) : x).join(' '), 'warn'); };
console.error = (...a) => { oErr(...a); logToDOM(a.map(x => typeof x === 'object' ? safeStringify(x) : x).join(' '), 'err'); };
window.addEventListener('error', e => logToDOM(`${e.message} at ${e.filename}:${e.lineno}`, 'err'));
window.addEventListener('unhandledrejection', e => logToDOM(e.reason, 'err'));

let gameStarted = false;
let isMpFlow = false;
let waitingForHost = false; // مهمان انتخاب‌هایش را کرده و منتظر نقشه میزبان است
export const getGameStarted = () => gameStarted;

let activeCrate = null;
export const activeFlares = [];

export function spawnCarePackageAt(targetPos) {
  const crateMesh = new THREE.Mesh(new THREE.BoxGeometry(1.8, 1.8, 1.8), new THREE.MeshStandardMaterial({ color: 0xb45309 }));
  crateMesh.position.set(targetPos.x, 45, targetPos.z);
  scene.add(crateMesh);
  activeCrate = { mesh: crateMesh, landed: false };
  playSound(250, 0.8, 'sawtooth', 0.4);
}

export function spawnAutoDrop() {
  spawnCarePackageAt(new THREE.Vector3(player.pos.x + (Math.random() - 0.5) * 8, 45, player.pos.z + (Math.random() - 0.5) * 8));
}

export function throwCarePackageFlare() {
  const flare = new THREE.Mesh(new THREE.CylinderGeometry(0.1, 0.1, 0.4, 8), new THREE.MeshStandardMaterial({ color: 0xef4444, emissive: 0xff0000 }));
  flare.position.copy(camera.position).add(camera.getWorldDirection(new THREE.Vector3()).multiplyScalar(1.0));
  scene.add(flare);
  const vel = camera.getWorldDirection(new THREE.Vector3()).multiplyScalar(15);
  vel.y += 5;
  activeFlares.push({ mesh: flare, vel: vel, timer: 2.5, landed: false });
  playSound(350, 0.2, 'sine', 0.4);
  showToast('🔴 فلر پرتاب شد!', '#ef4444');
}

setAutoDropCallback(spawnAutoDrop);
initEngine();
initControls(getGameStarted, throwCarePackageFlare);
initBuilder();

document.getElementById('btn-open-crate')?.addEventListener('click', () => {
  if (!activeCrate) return;
  scene.remove(activeCrate.mesh);
  activeCrate = null;
  const promptEl = document.getElementById('crate-prompt');
  if (promptEl) promptEl.style.display = 'none';
  playSound(800, 0.4, 'triangle', 0.5);
  const chosen = ['invincible', 'fire_ammo', 'allies', 'golden_mag'][Math.floor(Math.random() * 4)];
  if (chosen === 'invincible') {
    player.invincibleTimer = 20;
    showToast('🌿 آیتم جان‌سخت: ۲۰ ثانیه آسیب‌ناپذیری!', '#10b981');
  } else if (chosen === 'fire_ammo') {
    addFireBullets(5);
    showToast('🔥 آیتم تیر آتشین: ۵ تیر!', '#ef4444');
  } else if (chosen === 'allies') {
    spawnAlliedSoldiers();
  } else {
    activateGoldenMag(45);
    showToast('⚜ خشاب طلایی!', '#facc15');
  }
});

function hideAllModals() {
  document.querySelectorAll('.modal-overlay').forEach(m => m.style.display = 'none');
}

function isModalVisible(id) {
  const el = document.getElementById(id);
  return !!el && el.style.display === 'flex';
}

function enableGameControls() {
  const lookZone = document.getElementById('touch-look-zone');
  const joyZone = document.getElementById('joystick-zone');
  const canvas = document.getElementById('canvas-container');
  if (lookZone) lookZone.style.pointerEvents = 'auto';
  if (joyZone) joyZone.style.pointerEvents = 'auto';
  if (canvas) canvas.style.pointerEvents = 'auto';
  document.querySelectorAll('.hud-draggable').forEach(el => el.style.pointerEvents = 'auto');
}

// روی موبایل یک لمس هم pointerdown و هم click را اجرا می‌کند.
// قبلاً Handler دو بار اجرا می‌شد (دو Offer / دو Answer / دو بار setRemoteDescription).
// حالا هر دو Event گوش داده می‌شوند ولی Handler فقط یک بار در هر لمس اجرا می‌شود.
function addSafeClick(id, handler) {
  const el = document.getElementById(id);
  if (!el) return;
  let lastFire = 0;
  const cb = (e) => {
    e.preventDefault();
    e.stopPropagation();
    const now = performance.now();
    if (now - lastFire < 500) return;
    lastFire = now;
    handler(e);
  };
  el.addEventListener('pointerdown', cb);
  el.addEventListener('click', cb);
}

// دکمه‌های منوی اولیه
addSafeClick('btn-start-flow-solo', () => {
  isMpFlow = false;
  waitingForHost = false;
  resetNetwork(); // اگر قبلاً اتصال چندنفره نیمه‌کاره‌ای بوده، پاک شود
  openCharacterSelect();
});

addSafeClick('btn-start-flow-mp', () => {
  isMpFlow = true;
  hideAllModals();
  document.getElementById('mp-options-modal').style.display = 'flex';
});

// دکمه‌های چندنفره
addSafeClick('btn-create-offer', () => {
  createHostOffer();
});

addSafeClick('btn-confirm-host', async () => {
  const ok = await connectHost();
  if (ok) openCharacterSelect();
});

addSafeClick('btn-create-answer', () => {
  createJoinAnswer(() => {
    // فقط اگر مهمان هنوز در صفحه اتصال است، به انتخاب کاراکتر برود
    if (isModalVisible('mp-options-modal')) openCharacterSelect();
  });
});

addSafeClick('btn-mp-proceed', () => {
  if (!canProceedMultiplayer()) {
    showToast('اول اتصال را کامل کنید (کد اتاق / کد پاسخ)', '#eab308');
    return;
  }
  openCharacterSelect();
});

let chosenCharId = 'clone';
function openCharacterSelect() {
  hideAllModals();
  document.getElementById('character-select-modal').style.display = 'flex';
  const c = document.getElementById('character-list-container');
  c.innerHTML = '';

  Object.values(CHARACTERS_DB).forEach(char => {
    const d = document.createElement('div');
    d.className = 'select-card';
    d.innerHTML = `<div class="card-icon">${char.icon}</div><div class="card-title">${char.name}</div><div class="card-desc">${char.desc}</div>`;

    const pick = (e) => {
      e.stopPropagation();
      document.querySelectorAll('#character-list-container .select-card').forEach(x => x.classList.remove('selected'));
      d.classList.add('selected');
      chosenCharId = char.id;
      setCharacter(char.id);
    };
    d.addEventListener('pointerdown', pick);
    d.addEventListener('click', pick);
    c.appendChild(d);
  });

  if (c.firstChild) {
    c.firstChild.classList.add('selected');
    chosenCharId = Object.values(CHARACTERS_DB)[0].id;
    setCharacter(chosenCharId);
  }
}

addSafeClick('btn-confirm-character', () => openWeaponSelect());

let chosenWeaponId = 'rifle';
function openWeaponSelect() {
  hideAllModals();
  document.getElementById('weapon-select-modal').style.display = 'flex';
  const c = document.getElementById('weapon-list-container');
  c.innerHTML = '';

  Object.values(WEAPONS_DB).forEach(wpn => {
    const d = document.createElement('div');
    d.className = 'select-card';
    d.innerHTML = `<div class="card-icon">🔫</div><div class="card-title">${wpn.name}</div><div class="card-desc">Dmg: ${wpn.damage} | Mag: ${wpn.magSize}<br>Type: ${wpn.id}</div>`;

    const pick = (e) => {
      e.stopPropagation();
      document.querySelectorAll('#weapon-list-container .select-card').forEach(x => x.classList.remove('selected'));
      d.classList.add('selected');
      chosenWeaponId = wpn.id;
      setWeapon(wpn.id);
    };
    d.addEventListener('pointerdown', pick);
    d.addEventListener('click', pick);
    c.appendChild(d);
  });

  if (c.firstChild) {
    c.firstChild.classList.add('selected');
    chosenWeaponId = Object.values(WEAPONS_DB)[0].id;
    setWeapon(chosenWeaponId);
  }
}

addSafeClick('btn-confirm-weapon', () => {
  if (isMpFlow && !isHost) {
    // مهمان نقشه انتخاب نمی‌کند؛ نقشه از میزبان می‌آید
    if (hostMapId) {
      startGameSession(hostMapId);
    } else {
      waitingForHost = true;
      hideAllModals();
      const chip = document.getElementById('mp-chip');
      if (chip) { chip.innerText = '⏳ منتظر انتخاب نقشه میزبان'; chip.style.color = '#eab308'; }
      showToast('منتظر میزبان برای انتخاب نقشه...', '#38bdf8');
      requestHostInit();
    }
  } else {
    openMapSelect();
  }
});

let chosenMapId = 'maze';
function openMapSelect() {
  hideAllModals();
  document.getElementById('map-select-modal').style.display = 'flex';
  const c = document.getElementById('map-list-container');
  c.innerHTML = '';

  Object.values(MAPS_DB).forEach(map => {
    const d = document.createElement('div');
    d.className = 'select-card';
    d.style.flex = '0 0 120px';
    d.innerHTML = `<div class="card-title">${map.name}</div>`;

    const pick = (e) => {
      e.stopPropagation();
      document.querySelectorAll('#map-list-container .select-card').forEach(x => x.classList.remove('selected'));
      d.classList.add('selected');
      chosenMapId = map.id;
      startMapPreview(map.id);
    };
    d.addEventListener('pointerdown', pick);
    d.addEventListener('click', pick);
    c.appendChild(d);
  });

  if (c.firstChild) {
    c.firstChild.classList.add('selected');
    chosenMapId = Object.values(MAPS_DB)[0].id;
    startMapPreview(chosenMapId);
  }
}

function placeAtSpawn(mapId) {
  const map = MAPS_DB[mapId];
  if (map && map.spawns) {
    const spIdx = (isMpFlow && !isHost) ? 1 : 0;
    player.pos.copy(map.spawns[spIdx] || map.spawns[0]);
    player.vel.set(0, 0, 0);
  }
}

function startGameSession(mapId = chosenMapId) {
  if (!MAPS_DB[mapId]) mapId = 'maze';
  chosenMapId = mapId;
  waitingForHost = false;

  hideAllModals();
  enableGameControls();
  initWorld(mapId);
  placeAtSpawn(mapId);

  if (selectedCharacter && selectedCharacter.id === 'speedster') {
    player.baseSpeedMultiplier = 2.5;
  }

  if (!isMpFlow) {
    spawnEnemies();
  } else if (isHost) {
    // نقشه را به مهمان اعلام کن (اگر کانال هنوز باز نشده، هنگام باز شدن ارسال می‌شود)
    announceHostMap(mapId);
  }

  gameStarted = true;
  console.log('GAME STARTED. MAP:', MAPS_DB[mapId]?.name || mapId, '| MP:', isMpFlow, '| HOST:', isHost);
  showToast(`نبرد در نقشه ${MAPS_DB[mapId]?.name || mapId} آغاز شد!`, '#10b981');
}

// دریافت نقشه از میزبان (سمت مهمان)
setOnHostInit((d) => {
  if (!isMpFlow || isHost) return;
  if (waitingForHost) {
    startGameSession(d.map);
  } else if (gameStarted && d.map !== chosenMapId) {
    chosenMapId = d.map;
    initWorld(d.map);
    placeAtSpawn(d.map);
    showToast(`ورود به نقشه ${MAPS_DB[d.map].name}`, '#38bdf8');
  }
  // اگر مهمان هنوز در حال انتخاب کاراکتر/سلاح است، نقشه ذخیره شده و بعد از تایید سلاح استفاده می‌شود
});

addSafeClick('btn-confirm-map', () => startGameSession(chosenMapId));

addSafeClick('btn-settings-gear', () => {
  gameStarted = false;
  document.getElementById('gear-menu-modal').style.display = 'flex';
});

addSafeClick('gear-btn-hud-edit', () => {
  document.getElementById('gear-menu-modal').style.display = 'none';
  gameStarted = true;
  toggleHudEdit(true);
});

addSafeClick('gear-btn-mode', () => {
  toggleBuildMode();
  document.getElementById('gear-menu-modal').style.display = 'none';
  gameStarted = true;
});

document.querySelectorAll('.btn-back-menu').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.modal-overlay').forEach(m => m.style.display = 'none');
    gameStarted = true;
  });
});

const clock = new THREE.Clock();
let netTimer = 0;

function animate() {
  requestAnimationFrame(animate);
  const dt = Math.min(clock.getDelta(), 0.1);

  if (!gameStarted) return;

  updatePlayer(dt, moveInput);

  if (!isBuildMode) {
    updateWeapons(dt);
    if (!isMultiplayer) {
      updateEnemies(dt);
    }
    updateCharacters(dt, enemies, { player, scene, camera, enemiesList: enemies });
  }

  updateBuilder();
  updateNetwork(dt);

  if (isMultiplayer) {
    netTimer += dt;
    if (netTimer > 0.05) {
      sendNetworkData({
        t: 'm',
        x: Number(player.pos.x.toFixed(2)),
        y: Number(player.pos.y.toFixed(2)),
        z: Number(player.pos.z.toFixed(2)),
        ry: Number(player.rotY.toFixed(3)),
        sl: player.isSliding ? 1 : 0
      });
      netTimer = 0;
    }
  }

  for (let i = activeFlares.length - 1; i >= 0; i--) {
    const f = activeFlares[i];
    if (!f.landed) {
      f.vel.y -= 25 * dt;
      f.mesh.position.addScaledVector(f.vel, dt);
      if (f.mesh.position.y <= 0.2) {
        f.mesh.position.y = 0.2;
        f.landed = true;
        playSound(150, 0.2, 'sawtooth', 0.2);
      }
    } else {
      f.timer -= dt;
      if (f.timer <= 0) {
        spawnCarePackageAt(f.mesh.position);
        scene.remove(f.mesh);
        activeFlares.splice(i, 1);
      }
    }
  }

  if (activeCrate) {
    if (!activeCrate.landed) {
      activeCrate.mesh.position.y -= 12.0 * dt;
      if (activeCrate.mesh.position.y <= 0.9) {
        activeCrate.mesh.position.y = 0.9;
        activeCrate.landed = true;
        playSound(200, 0.3, 'sawtooth', 0.3);
      }
    } else {
      const dist = player.pos.distanceTo(activeCrate.mesh.position);
      const promptEl = document.getElementById('crate-prompt');
      if (promptEl) promptEl.style.display = (dist < 3.5) ? 'block' : 'none';
    }
  }

  renderer.render(scene, camera);
}

animate();
